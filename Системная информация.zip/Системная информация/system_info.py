import platform
import os
import psutil
import socket

def get_system_info():
    print("Системная информация:")
    print("---------------------")
    print(f"Операционная система: {platform.system()} {platform.release()} ({platform.version()})")
    print(f"Архитектура: {platform.architecture()[0]}")
    print(f"Процессор: {platform.processor()}")
    print(f"Количество ядер: {psutil.cpu_count(logical=True)}")
    print(f"Частота процессора: {psutil.cpu_freq().max:.2f} MHz")
    print(f"Оперативная память: {psutil.virtual_memory().total / (1024 ** 3):.2f} GB")
    print(f"Имя устройства: {platform.node()}")
    print(f"IP-адрес: {socket.gethostbyname(socket.gethostname())}")

    # Проверка заряда батареи (если есть)
    if hasattr(psutil, "sensors_battery"):
        battery = psutil.sensors_battery()
        if battery:
            print(f"Уровень заряда батареи: {battery.percent}%")

    input("\nНажмите Enter для выхода...")  # Ожидаем нажатие клавиши

get_system_info()
